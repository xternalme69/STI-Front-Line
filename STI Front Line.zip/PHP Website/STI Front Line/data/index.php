<html>
	<head>
		<title>STI Front Line</title>
		<!--CSS Below-->
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<!--CSS Above-->
		<!--JS Below-->
		<script>
			window.setTimeout(function(){
			window.location.href = "../index.php";
		}, 0);
		</script>
		<!--JS Above-->
	</head>
	<body>
	</body>
</html>